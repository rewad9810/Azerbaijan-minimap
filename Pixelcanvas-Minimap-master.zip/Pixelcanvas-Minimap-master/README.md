# Pixelcanvas-Minimap
### setup & update URL
[minimap.user.js](https://github.com/Priz001/Pixelcanvas-Minimap/raw/master/minimap.user.js)
